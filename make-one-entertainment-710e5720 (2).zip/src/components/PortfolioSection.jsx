import React from "react";

export default function PortfolioSection() {
  return (
    <section id="portfolio" className="py-8 md:py-12 bg-white">
      {/* 새로운 디자인을 위한 빈 공간 */}
    </section>
  );
}